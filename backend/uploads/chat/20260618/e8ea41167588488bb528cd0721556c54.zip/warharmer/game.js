// ============================================================
// 音频引擎
// ============================================================
class AudioEngine {
    constructor() {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.5;
        this.master.connect(this.ctx.destination);
    }

    // 生成噪声缓冲（用于爆炸、枪声等）
    _createNoiseBuffer(duration, sampleRate) {
        const bufferSize = sampleRate * duration;
        const buffer = this.ctx.createBuffer(1, bufferSize, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
        return buffer;
    }

    // 播放短促低音冲击
    _playThump(freq, duration, vol, delay = 0) {
        const t = this.ctx.currentTime + delay;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(freq, t);
        osc.frequency.exponentialRampToValueAtTime(30, t + duration);
        gain.gain.setValueAtTime(vol, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + duration);
    }

    playTone(freq, duration, type = 'sine', vol = 0.3, delay = 0) {
        const t = this.ctx.currentTime + delay;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(vol, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + duration);
    }

    // 爆矢枪：巨大的轰鸣声 + 低频冲击 + 金属回响
    playGunshot() {
        const t = this.ctx.currentTime;
        // 低频冲击
        this._playThump(150, 0.2, 0.8, 0);
        // 高频爆鸣
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(600, t);
        osc.frequency.exponentialRampToValueAtTime(80, t + 0.15);
        gain.gain.setValueAtTime(0.6, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + 0.2);
        // 噪声爆裂
        const noise = this.ctx.createBufferSource();
        noise.buffer = this._createNoiseBuffer(0.15, this.ctx.sampleRate);
        const noiseGain = this.ctx.createGain();
        noiseGain.gain.setValueAtTime(0.5, t);
        noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
        noise.connect(noiseGain);
        noiseGain.connect(this.master);
        noise.start(t);
        // 金属回响
        this.playTone(800, 0.08, 'square', 0.15, 0.05);
        this.playTone(1200, 0.06, 'sine', 0.1, 0.08);
    }

    // 近战：动力剑嗡鸣 + 重击
    playMelee() {
        const t = this.ctx.currentTime;
        // 链锯嗡鸣
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(180, t);
        osc.frequency.linearRampToValueAtTime(220, t + 0.08);
        gain.gain.setValueAtTime(0.4, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + 0.12);
        // 重击
        this._playThump(100, 0.15, 0.7, 0.02);
        this.playTone(250, 0.1, 'square', 0.4, 0.02);
    }

    // 技能斩击：呼啸风声 + 强力冲击
    playSkillSwing() {
        const t = this.ctx.currentTime;
        // 多重呼啸
        for (let i = 0; i < 3; i++) {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(400 - i * 80, t + i * 0.03);
            osc.frequency.exponentialRampToValueAtTime(60, t + i * 0.03 + 0.15);
            gain.gain.setValueAtTime(0.35, t + i * 0.03);
            gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.03 + 0.15);
            osc.connect(gain);
            gain.connect(this.master);
            osc.start(t + i * 0.03);
            osc.stop(t + i * 0.03 + 0.15);
        }
        // 强力冲击
        this._playThump(80, 0.3, 0.9, 0.05);
        this._playThump(60, 0.25, 0.7, 0.1);
        // 金属撕裂声
        this.playTone(200, 0.2, 'square', 0.4, 0.08);
    }

    playDeath() {
        const t = this.ctx.currentTime;
        this._playThump(80, 0.5, 0.6);
        this.playTone(120, 0.3, 'sawtooth', 0.4);
        this.playTone(60, 0.4, 'square', 0.3, 0.05);
    }

    playHit() {
        const t = this.ctx.currentTime;
        this._playThump(200, 0.1, 0.5);
        this.playTone(300, 0.08, 'square', 0.3);
        this.playTone(150, 0.12, 'sawtooth', 0.25, 0.02);
    }

    playPickup() {
        const t = this.ctx.currentTime;
        this.playTone(500, 0.08, 'sine', 0.3);
        this.playTone(700, 0.1, 'sine', 0.25, 0.06);
        this.playTone(1000, 0.12, 'sine', 0.2, 0.12);
    }

    // 强化爆弹射击：更响亮的轰鸣
    playPoweredShot() {
        const t = this.ctx.currentTime;
        // 更强的低频冲击
        this._playThump(120, 0.25, 1.0, 0);
        // 更响的高频爆鸣
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(500, t);
        osc.frequency.exponentialRampToValueAtTime(60, t + 0.2);
        gain.gain.setValueAtTime(0.8, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + 0.25);
        // 更强的噪声爆裂
        const noise = this.ctx.createBufferSource();
        noise.buffer = this._createNoiseBuffer(0.2, this.ctx.sampleRate);
        const noiseGain = this.ctx.createGain();
        noiseGain.gain.setValueAtTime(0.7, t);
        noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        noise.connect(noiseGain);
        noiseGain.connect(this.master);
        noise.start(t);
        // 金属回响
        this.playTone(600, 0.1, 'square', 0.25, 0.05);
        this.playTone(900, 0.08, 'sine', 0.2, 0.08);
    }

    // 换弹：机械咔哒声
    playReload() {
        const t = this.ctx.currentTime;
        [0, 0.06, 0.12, 0.2].forEach((delay, i) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'square';
            osc.frequency.setValueAtTime(600 + (i % 2) * 300, t + delay);
            gain.gain.setValueAtTime(0.25, t + delay);
            gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.06);
            osc.connect(gain);
            gain.connect(this.master);
            osc.start(t + delay);
            osc.stop(t + delay + 0.06);
        });
        this._playThump(300, 0.08, 0.3, 0.15);
    }

    // 敌人吼叫：更低沉、更恐怖
    playEnemyRoar() {
        const t = this.ctx.currentTime;
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc1.type = 'sawtooth';
        osc2.type = 'square';
        osc1.frequency.setValueAtTime(80, t);
        osc1.frequency.exponentialRampToValueAtTime(35, t + 0.5);
        osc2.frequency.setValueAtTime(55, t);
        osc2.frequency.exponentialRampToValueAtTime(25, t + 0.5);
        gain.gain.setValueAtTime(0.4, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(this.master);
        osc1.start(t);
        osc2.start(t);
        osc1.stop(t + 0.5);
        osc2.stop(t + 0.5);
        this._playThump(60, 0.3, 0.4, 0);
    }

    // 恐虐冲锋：引擎轰鸣 + 咆哮
    playCharge() {
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, t);
        osc.frequency.exponentialRampToValueAtTime(500, t + 0.4);
        gain.gain.setValueAtTime(0.4, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + 0.5);
        this._playThump(100, 0.4, 0.6, 0);
        this._playThump(80, 0.35, 0.5, 0.1);
    }

    // 爆炸音效
    playExplosion() {
        const t = this.ctx.currentTime;
        // 低频冲击
        this._playThump(60, 0.4, 0.9);
        this._playThump(40, 0.5, 0.7, 0.05);
        // 噪声爆裂
        const noise = this.ctx.createBufferSource();
        noise.buffer = this._createNoiseBuffer(0.3, this.ctx.sampleRate);
        const noiseGain = this.ctx.createGain();
        noiseGain.gain.setValueAtTime(0.6, t);
        noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
        noise.connect(noiseGain);
        noiseGain.connect(this.master);
        noise.start(t);
        // 高频碎片
        this.playTone(300, 0.15, 'sawtooth', 0.4);
        this.playTone(500, 0.1, 'square', 0.3, 0.05);
    }
}

// ============================================================
// 粒子系统
// ============================================================
class ParticleSystem {
    constructor() {
        this.particles = [];
    }

    spawnBlood(x, y, intensity = 0.3) {
        const count = Math.floor(5 + intensity * 15);
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 1 + Math.random() * 4 * intensity;
            this.particles.push({
                x, y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                life: 1.0,
                decay: 0.02 + Math.random() * 0.03,
                size: 1 + Math.random() * 3,
                color: `hsl(${0 + Math.random() * 20}, 90%, ${40 + Math.random() * 30}%)`,
                type: 'blood'
            });
        }
    }

    spawnDeathExplosion(x, y) {
        for (let i = 0; i < 25; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 1 + Math.random() * 5;
            this.particles.push({
                x, y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                life: 1.0,
                decay: 0.015 + Math.random() * 0.02,
                size: 2 + Math.random() * 6,
                color: `hsl(${30 + Math.random() * 30}, 100%, ${50 + Math.random() * 30}%)`,
                type: 'fire'
            });
        }
        for (let i = 0; i < 10; i++) {
            this.particles.push({
                x, y,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                life: 1.0,
                decay: 0.01 + Math.random() * 0.01,
                size: 3 + Math.random() * 8,
                color: `rgba(80, 80, 80, ${0.3 + Math.random() * 0.4})`,
                type: 'smoke'
            });
        }
    }

    spawnMuzzleFlash(x, y, angle, powered = false) {
        const count = powered ? 15 : 8;
        const hueBase = powered ? 20 : 40;
        const sizeMult = powered ? 1.5 : 1;
        for (let i = 0; i < count; i++) {
            const a = angle + (Math.random() - 0.5) * (powered ? 0.8 : 0.5);
            const speed = 2 + Math.random() * 4;
            this.particles.push({
                x, y,
                vx: Math.cos(a) * speed,
                vy: Math.sin(a) * speed,
                life: 1.0,
                decay: 0.05 + Math.random() * 0.05,
                size: (1 + Math.random() * 3) * sizeMult,
                color: `hsl(${hueBase + Math.random() * 20}, 100%, ${powered ? 60 : 70}%)`,
                type: 'fire'
            });
        }
    }

    update() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx;
            p.y += p.vy;
            p.life -= p.decay;
            if (p.life <= 0) this.particles.splice(i, 1);
        }
    }

    draw(ctx) {
        for (const p of this.particles) {
            const alpha = Math.max(0, p.life);
            ctx.globalAlpha = alpha;
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1.0;
    }
}

// ============================================================
// 场景（地图、障碍、装饰）
// ============================================================
class Scene {
    constructor(w, h) {
        this.w = w;
        this.h = h;
        this.obstacles = [];
        this.decorations = [];
        this.generate();
    }

    generate() {
        this.obstacles.push({ x: 0, y: 0, w: this.w, h: 40 });
        this.obstacles.push({ x: 0, y: this.h - 40, w: this.w, h: 40 });
        this.obstacles.push({ x: 0, y: 0, w: 40, h: this.h });
        this.obstacles.push({ x: this.w - 40, y: 0, w: 40, h: this.h });

        const count = 15 + Math.floor(Math.random() * 10);
        for (let i = 0; i < count; i++) {
            const w = 40 + Math.random() * 120;
            const h = 40 + Math.random() * 120;
            const x = 80 + Math.random() * (this.w - 160 - w);
            const y = 80 + Math.random() * (this.h - 160 - h);
            this.obstacles.push({ x, y, w, h });
        }

        for (let i = 0; i < 60; i++) {
            const types = ['debris', 'skull', 'rust', 'oil', 'pipe', 'barrel', 'cable'];
            const weights = [0.25, 0.1, 0.2, 0.15, 0.1, 0.1, 0.1];
            let rand = Math.random();
            let type = 'debris';
            for (let j = 0; j < weights.length; j++) {
                rand -= weights[j];
                if (rand <= 0) { type = types[j]; break; }
            }
            this.decorations.push({
                x: Math.random() * this.w,
                y: Math.random() * this.h,
                size: 2 + Math.random() * 8,
                type,
                rot: Math.random() * Math.PI * 2
            });
        }
    }

    isBlocked(x, y, radius) {
        for (const obs of this.obstacles) {
            const closestX = Math.max(obs.x, Math.min(x, obs.x + obs.w));
            const closestY = Math.max(obs.y, Math.min(y, obs.y + obs.h));
            const dx = x - closestX;
            const dy = y - closestY;
            if (dx * dx + dy * dy < radius * radius) return true;
        }
        return false;
    }

    resolveCollision(x, y, radius, oldX, oldY) {
        for (const obs of this.obstacles) {
            const closestX = Math.max(obs.x, Math.min(x, obs.x + obs.w));
            const closestY = Math.max(obs.y, Math.min(y, obs.y + obs.h));
            const dx = x - closestX;
            const dy = y - closestY;
            const distSq = dx * dx + dy * dy;
            if (distSq < radius * radius && distSq > 0) {
                const dist = Math.sqrt(distSq);
                x += (dx / dist) * (radius - dist + 1);
                y += (dy / dist) * (radius - dist + 1);
            }
        }
        x = Math.max(radius, Math.min(this.w - radius, x));
        y = Math.max(radius, Math.min(this.h - radius, y));
        return { x, y };
    }

    drawFloor(ctx) {
        // 深色金属地板底色
        ctx.fillStyle = '#141618';
        ctx.fillRect(0, 0, this.w, this.h);

        // 工业地板网格（粗大金属板）
        ctx.strokeStyle = '#1e2024';
        ctx.lineWidth = 2;
        for (let x = 0; x < this.w; x += 80) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.h); ctx.stroke();
        }
        for (let y = 0; y < this.h; y += 80) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.w, y); ctx.stroke();
        }

        // 铆钉/螺栓细节
        ctx.fillStyle = '#222';
        for (let x = 0; x < this.w; x += 80) {
            for (let y = 0; y < this.h; y += 80) {
                ctx.beginPath(); ctx.arc(x + 3, y + 3, 2, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(x + 77, y + 3, 2, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(x + 3, y + 77, 2, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(x + 77, y + 77, 2, 0, Math.PI * 2); ctx.fill();
            }
        }

        // 随机锈迹和污渍
        for (const d of this.decorations) {
            if (d.type === 'rust') {
                ctx.fillStyle = `rgba(120, 60, 20, ${0.15 + d.size * 0.02})`;
                ctx.beginPath();
                ctx.arc(d.x, d.y, d.size * 3, 0, Math.PI * 2);
                ctx.fill();
            } else if (d.type === 'oil') {
                ctx.fillStyle = `rgba(20, 20, 30, ${0.3 + d.size * 0.03})`;
                ctx.beginPath();
                ctx.ellipse(d.x, d.y, d.size * 4, d.size * 2, d.rot, 0, Math.PI * 2);
                ctx.fill();
            }
        }
    }

    drawDeco(ctx) {
        for (const d of this.decorations) {
            if (d.type === 'debris') {
                // 混凝土/金属碎片
                ctx.fillStyle = '#2a2a2c';
                ctx.fillRect(d.x - d.size / 2, d.y - d.size / 2, d.size, d.size);
                ctx.fillStyle = '#1a1a1c';
                ctx.fillRect(d.x - d.size / 4, d.y - d.size / 4, d.size / 2, d.size / 2);
            } else if (d.type === 'skull') {
                // 骷髅
                ctx.fillStyle = '#777';
                ctx.beginPath();
                ctx.arc(d.x, d.y, d.size * 0.6, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = '#444';
                ctx.beginPath();
                ctx.arc(d.x - d.size * 0.2, d.y + d.size * 0.2, d.size * 0.15, 0, Math.PI * 2);
                ctx.fill();
                ctx.beginPath();
                ctx.arc(d.x + d.size * 0.2, d.y + d.size * 0.2, d.size * 0.15, 0, Math.PI * 2);
                ctx.fill();
            } else if (d.type === 'pipe') {
                // 管道
                ctx.fillStyle = '#333';
                ctx.fillRect(d.x - d.size * 3, d.y - d.size * 0.4, d.size * 6, d.size * 0.8);
                ctx.fillStyle = '#444';
                ctx.fillRect(d.x - d.size * 3, d.y - d.size * 0.15, d.size * 6, d.size * 0.3);
            } else if (d.type === 'barrel') {
                // 帝国风格桶
                ctx.fillStyle = '#3a3020';
                ctx.beginPath();
                ctx.ellipse(d.x, d.y, d.size, d.size * 0.6, 0, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#555';
                ctx.lineWidth = 1;
                ctx.stroke();
                ctx.fillStyle = '#222';
                ctx.fillRect(d.x - d.size * 0.3, d.y - d.size * 0.5, d.size * 0.6, d.size);
            } else if (d.type === 'cable') {
                // 电缆
                ctx.strokeStyle = '#2a2520';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(d.x, d.y);
                ctx.lineTo(d.x + Math.cos(d.rot) * d.size * 5, d.y + Math.sin(d.rot) * d.size * 5);
                ctx.stroke();
            }
        }
    }

    drawObstacles(ctx) {
        for (const obs of this.obstacles) {
            const isWall = obs.x === 0 || obs.y === 0 || obs.x + obs.w >= this.w || obs.y + obs.h >= this.h;

            if (isWall) {
                // 哥特式墙壁/边界
                ctx.fillStyle = '#181a1c';
                ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
                ctx.strokeStyle = '#2a2d30';
                ctx.lineWidth = 2;
                ctx.strokeRect(obs.x, obs.y, obs.w, obs.h);

                // 墙壁装饰线条
                ctx.strokeStyle = '#222';
                ctx.lineWidth = 1;
                if (obs.w > obs.h) {
                    for (let i = obs.x + 20; i < obs.x + obs.w - 20; i += 60) {
                        ctx.beginPath(); ctx.moveTo(i, obs.y); ctx.lineTo(i, obs.y + obs.h); ctx.stroke();
                        // 哥特式尖拱装饰
                        ctx.fillStyle = '#1a1c1e';
                        ctx.beginPath();
                        ctx.moveTo(i + 5, obs.y + 5);
                        ctx.lineTo(i + 15, obs.y + 5);
                        ctx.lineTo(i + 10, obs.y + 15);
                        ctx.closePath();
                        ctx.fill();
                    }
                } else {
                    for (let j = obs.y + 20; j < obs.y + obs.h - 20; j += 60) {
                        ctx.beginPath(); ctx.moveTo(obs.x, j); ctx.lineTo(obs.x + obs.w, j); ctx.stroke();
                    }
                }
            } else {
                // 工业废墟/柱子
                ctx.fillStyle = '#1e2024';
                ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
                ctx.strokeStyle = '#333';
                ctx.lineWidth = 2;
                ctx.strokeRect(obs.x, obs.y, obs.w, obs.h);

                // 警示条纹
                ctx.fillStyle = '#3a3020';
                for (let i = 0; i < Math.min(obs.w, obs.h); i += 12) {
                    ctx.fillRect(obs.x + i, obs.y, 6, 4);
                    ctx.fillRect(obs.x, obs.y + i, 4, 6);
                    ctx.fillRect(obs.x + obs.w - 6, obs.y + i, 6, 6);
                    ctx.fillRect(obs.x + i, obs.y + obs.h - 4, 6, 4);
                }

                // 金属板铆钉
                ctx.fillStyle = '#2a2a2c';
                for (let i = obs.x + 8; i < obs.x + obs.w - 8; i += 20) {
                    for (let j = obs.y + 8; j < obs.y + obs.h - 8; j += 20) {
                        ctx.beginPath(); ctx.arc(i, j, 2, 0, Math.PI * 2); ctx.fill();
                    }
                }
            }
        }
    }

    drawLighting(ctx, time) {
        // 更暗的基础氛围
        ctx.fillStyle = 'rgba(5, 5, 8, 0.5)';
        ctx.fillRect(0, 0, this.w, this.h);

        // 闪烁的工业灯光
        const flicker1 = 0.85 + Math.sin(time * 0.08) * 0.1 + Math.sin(time * 0.3) * 0.05;
        const flicker2 = 0.85 + Math.sin(time * 0.06 + 1) * 0.1 + Math.sin(time * 0.27 + 2) * 0.05;
        const lights = [
            { x: this.w * 0.25, y: this.h * 0.25, color: '200, 160, 80', flicker: flicker1 },
            { x: this.w * 0.75, y: this.h * 0.25, color: '200, 160, 80', flicker: flicker2 },
            { x: this.w * 0.25, y: this.h * 0.75, color: '200, 160, 80', flicker: flicker2 },
            { x: this.w * 0.75, y: this.h * 0.75, color: '200, 160, 80', flicker: flicker1 },
            { x: this.w * 0.5, y: this.h * 0.5, color: '180, 60, 40', flicker: flicker1 * 0.6 }
        ];
        for (const l of lights) {
            const grad = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, 250);
            grad.addColorStop(0, `rgba(${l.color}, ${0.12 * l.flicker})`);
            grad.addColorStop(0.5, `rgba(${l.color}, ${0.04 * l.flicker})`);
            grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(l.x, l.y, 250, 0, Math.PI * 2);
            ctx.fill();
        }

        // 顶部边缘的工业灯管
        ctx.fillStyle = `rgba(200, 180, 140, ${0.03 * flicker1})`;
        ctx.fillRect(0, 0, this.w, 60);
        ctx.fillRect(0, this.h - 60, this.w, 60);
    }

    draw(ctx, time) {
        this.drawFloor(ctx);
        this.drawDeco(ctx);
        this.drawObstacles(ctx);
        this.drawLighting(ctx, time);
    }
}

// ============================================================
// 玩家类
// ============================================================
class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 18;
        this.speed = 3.5;
        this.angle = 0;
        this.maxHealth = 120;
        this.health = 120;
        this.clipSize = 30;
        this.ammo = 30;
        this.reserveAmmo = 120;
        this.reloading = false;
        this.reloadTime = 90;
        this.reloadTimer = 0;
        this.meleeCooldown = 0;
        this.meleeActive = false;
        this.meleeAngle = 0;
        this.meleeDuration = 0;
        this.invincible = 0;
        this.shootCooldown = 0;
        this.justHit = false;
        this.justMelee = false;
        this.justReloaded = false;

        this.skillCooldownMax = 1200;
        this.skillCooldown = 0;
        this.skillActive = false;
        this.skillAngle = 0;
        this.skillDuration = 0;
        this.skillRange = 170;
        this.skillDamage = 80;
        this.justSkill = false;

        this.slaaneshSlow = 1;

        // 强化子弹计数
        this.powerUpAmmo = 0;

        // 濒死救援（仅一次）
        this.usedRevive = false;
    }

    update(input, scene) {
        let dx = 0, dy = 0;
        if (input.keys['w'] || input.keys['W']) dy -= 1;
        if (input.keys['s'] || input.keys['S']) dy += 1;
        if (input.keys['a'] || input.keys['A']) dx -= 1;
        if (input.keys['d'] || input.keys['D']) dx += 1;

        if (dx !== 0 || dy !== 0) {
            const len = Math.sqrt(dx * dx + dy * dy);
            dx /= len; dy /= len;
        }

        const newX = this.x + dx * this.speed * (this.slaaneshSlow || 1);
        const newY = this.y + dy * this.speed * (this.slaaneshSlow || 1);
        const resolved = scene.resolveCollision(newX, newY, this.radius, this.x, this.y);
        this.x = resolved.x;
        this.y = resolved.y;
        this.slaaneshSlow = 1;

        this.angle = Math.atan2(input.mouseY - this.y, input.mouseX - this.x);

        if (this.meleeCooldown > 0) this.meleeCooldown--;
        if (this.meleeDuration > 0) {
            this.meleeDuration--;
            if (this.meleeDuration <= 0) this.meleeActive = false;
        }
        if (this.invincible > 0) this.invincible--;
        if (this.shootCooldown > 0) this.shootCooldown--;
        if (this.skillCooldown > 0) this.skillCooldown--;
        if (this.skillDuration > 0) this.skillDuration--;
        if (this.skillDuration <= 0) this.skillActive = false;

        if (this.reloading) {
            this.reloadTimer--;
            if (this.reloadTimer <= 0) {
                const need = this.clipSize - this.ammo;
                const take = Math.min(need, this.reserveAmmo);
                this.ammo += take;
                this.reserveAmmo -= take;
                this.reloading = false;
                this.justReloaded = true;
            }
        }

        if (this.ammo <= 0 && !this.reloading && this.reserveAmmo > 0) {
            this.startReload();
        }

        this.justHit = false;
        this.justReloaded = false;
    }

    startReload() {
        if (this.reloading || this.ammo >= this.clipSize || this.reserveAmmo <= 0) return;
        this.reloading = true;
        this.reloadTimer = this.reloadTime;
    }

    takeDamage(amount) {
        if (this.invincible > 0) return;
        this.health -= amount;
        this.invincible = 15;
        this.justHit = true;
        if (this.health < 0) this.health = 0;
    }

    heal(amount) {
        this.health = Math.min(this.maxHealth, this.health + amount);
    }

    getMuzzlePosition() {
        return {
            x: this.x + Math.cos(this.angle) * (this.radius + 5),
            y: this.y + Math.sin(this.angle) * (this.radius + 5)
        };
    }

    startMelee() {
        if (this.meleeCooldown > 0) return;
        this.meleeActive = true;
        this.meleeDuration = 15;
        this.meleeCooldown = 40;
        this.meleeAngle = this.angle;
        this.justMelee = true;
    }

    startSkill() {
        if (this.skillCooldown > 0) return;
        this.skillActive = true;
        this.skillDuration = 20;
        this.skillCooldown = this.skillCooldownMax;
        this.skillAngle = this.angle;
        this.justSkill = true;
    }

    getMeleeHitbox() {
        if (!this.meleeActive || this.meleeDuration < 5) return null;
        return {
            x: this.x,
            y: this.y,
            radius: 55,
            startAngle: this.meleeAngle - Math.PI * 0.35,
            endAngle: this.meleeAngle + Math.PI * 0.35
        };
    }

    draw(ctx) {
        if (this.health <= 0) return;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);

        // 动力背包
        ctx.fillStyle = '#1a3a6a';
        ctx.fillRect(-10, 10, 20, 12);
        ctx.fillStyle = '#0d2850';
        ctx.fillRect(-8, 12, 16, 8);

        // 主体动力甲
        ctx.fillStyle = '#0a3a8a';
        ctx.beginPath();
        ctx.ellipse(0, 0, this.radius, this.radius * 0.9, 0, 0, Math.PI * 2);
        ctx.fill();

        // 胸甲金色镶边
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, this.radius - 2, this.radius * 0.9 - 2, 0, 0, Math.PI * 2);
        ctx.stroke();

        // 极限战士肩甲（左）
        ctx.fillStyle = '#0a3a8a';
        ctx.beginPath();
        ctx.ellipse(-14, -8, 7, 9, -0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 2;
        ctx.stroke();
        // 肩甲金色装饰
        ctx.fillStyle = '#d4af37';
        ctx.fillRect(-16, -12, 3, 8);

        // 极限战士肩甲（右）
        ctx.fillStyle = '#0a3a8a';
        ctx.beginPath();
        ctx.ellipse(14, -8, 7, 9, 0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = '#d4af37';
        ctx.fillRect(13, -12, 3, 8);

        // 头盔
        ctx.fillStyle = '#0d4088';
        ctx.beginPath();
        ctx.arc(0, -4, 9, 0, Math.PI * 2);
        ctx.fill();
        // 头盔金色冠饰（桂冠）
        ctx.fillStyle = '#d4af37';
        ctx.beginPath();
        ctx.arc(0, -11, 5, Math.PI, 0);
        ctx.stroke();
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-4, -10); ctx.lineTo(-4, -14);
        ctx.moveTo(-1, -11); ctx.lineTo(-1, -15);
        ctx.moveTo(2, -11); ctx.lineTo(2, -15);
        ctx.moveTo(5, -10); ctx.lineTo(5, -14);
        ctx.stroke();

        // 目镜（红色发光）
        ctx.fillStyle = '#cc0000';
        ctx.shadowColor = '#ff0000';
        ctx.shadowBlur = 4;
        ctx.fillRect(-5, -6, 4, 2);
        ctx.fillRect(1, -6, 4, 2);
        ctx.shadowBlur = 0;

        // 呼吸格栅
        ctx.fillStyle = '#333';
        ctx.fillRect(-3, 0, 6, 3);
        ctx.fillStyle = '#555';
        ctx.fillRect(-2, 0.5, 1, 2);
        ctx.fillRect(0, 0.5, 1, 2);
        ctx.fillRect(2, 0.5, 1, 2);

        // 双头鹰徽记（金色简化版）
        ctx.fillStyle = '#d4af37';
        ctx.beginPath();
        ctx.arc(0, 4, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#b8960c';
        ctx.beginPath();
        ctx.moveTo(-2, 4); ctx.lineTo(-5, 1); ctx.lineTo(-3, 4); ctx.lineTo(-5, 7); ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(2, 4); ctx.lineTo(5, 1); ctx.lineTo(3, 4); ctx.lineTo(5, 7); ctx.closePath();
        ctx.fill();

        // 爆矢枪（更大更有特征）
        ctx.fillStyle = '#2a2a2a';
        ctx.fillRect(12, -5, 18, 7);
        ctx.fillStyle = '#111';
        ctx.fillRect(14, -3, 14, 4);
        // 枪管
        ctx.fillStyle = '#444';
        ctx.fillRect(28, -3, 8, 3);
        ctx.fillStyle = '#666';
        ctx.fillRect(30, -2.5, 4, 2);
        // 弹匣
        ctx.fillStyle = '#1a1a1a';
        ctx.fillRect(18, 2, 5, 6);
        // 瞄准镜
        ctx.fillStyle = '#333';
        ctx.fillRect(16, -7, 6, 2);
        ctx.fillStyle = '#cc0000';
        ctx.fillRect(18, -7, 2, 2);

        ctx.restore();

        if (this.invincible > 0 && this.invincible % 4 < 2) {
            ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 2, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

// ============================================================
// 子弹类
// ============================================================
class Bullet {
    constructor(x, y, angle, powered = false) {
        this.x = x;
        this.y = y;
        this.vx = Math.cos(angle) * 10;
        this.vy = Math.sin(angle) * 10;
        this.powered = powered;
        this.radius = powered ? 5 : 3;
        this.damage = powered ? 36 : 18;
        this.life = 60;
    }

    update(scene) {
        this.x += this.vx;
        this.y += this.vy;
        this.life--;
        if (this.x < 0 || this.x > scene.w || this.y < 0 || this.y > scene.h) return false;
        for (const obs of scene.obstacles) {
            const closestX = Math.max(obs.x, Math.min(this.x, obs.x + obs.w));
            const closestY = Math.max(obs.y, Math.min(this.y, obs.y + obs.h));
            const dx = this.x - closestX;
            const dy = this.y - closestY;
            if (dx * dx + dy * dy < this.radius * this.radius) return false;
        }
        return this.life > 0;
    }

    draw(ctx) {
        if (this.powered) {
            // 强化子弹：更大、发光、橙红色
            ctx.shadowColor = '#ff6600';
            ctx.shadowBlur = 8;
            ctx.fillStyle = '#ff4400';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ffaa00';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius - 2, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
            // 拖尾效果
            ctx.strokeStyle = 'rgba(255, 100, 0, 0.5)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(this.x, this.y);
            ctx.lineTo(this.x - this.vx * 2, this.y - this.vy * 2);
            ctx.stroke();
        } else {
            // 普通子弹
            ctx.fillStyle = '#ffcc00';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ff8800';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 1, 0, Math.PI * 2);
            ctx.stroke();
        }
    }
}

// ============================================================
// 四阵营混沌系统
// ============================================================
const FACTIONS = {
    // 恐虐：高攻中血，冲锋型
    khorne:   { name: '恐虐', color: '#8b0000', dColor: '#4a0000', mHp: 60, dHp: 240, mSpd: 2.3, dSpd: 2.1,  mDmg: 12, dDmg: 28, mRad: 15, dRad: 24, atkInt: 40 },
    // 纳垢：极厚血极低移速，毒池型
    nurgle:   { name: '纳垢', color: '#5a8a3a', dColor: '#2a5a1a', mHp: 110,dHp: 400, mSpd: 1.1, dSpd: 0.9,  mDmg: 6,  dDmg: 12, mRad: 20, dRad: 28, atkInt: 55 },
    // 奸奇：低血高机动，远程灵能
    tzeentch: { name: '奸奇', color: '#3a7aca', dColor: '#1a3a7a', mHp: 35, dHp: 120, mSpd: 2.7, dSpd: 2.4,  mDmg: 7,  dDmg: 16, mRad: 14, dRad: 18, atkInt: 50 },
    // 色孽：极低血极高速，魅惑减速
    slaanesh: { name: '色孽', color: '#9a4a9a', dColor: '#6a1a6a', mHp: 40, dHp: 110, mSpd: 3.3, dSpd: 4.2,  mDmg: 9,  dDmg: 18, mRad: 14, dRad: 18, atkInt: 45 }
};

// ============================================================
// 敌人类
// ============================================================
class Enemy {
    constructor(x, y, faction, rank) {
        this.x = x;
        this.y = y;
        this.faction = faction;
        this.rank = rank;
        const f = FACTIONS[faction];
        this.radius = rank === 'demon' ? f.dRad : f.mRad;
        this.maxHealth = rank === 'demon' ? f.dHp : f.mHp;
        this.health = this.maxHealth;
        this.speed = rank === 'demon' ? f.dSpd : f.mSpd;
        this.damage = rank === 'demon' ? f.dDmg : f.mDmg;
        this.attackCooldown = 0;
        this.attackInterval = f.atkInt;
        this.boltCooldown = Math.floor(Math.random() * 60);
        this.stagger = 0;
        this.deathTimer = 0;
        this.dead = false;
        this.walkOffset = Math.random() * Math.PI * 2;
        this.jitter = 0;

        if (rank === 'demon') {
            if (faction === 'khorne') {
                this.chargeCooldown = 300;
                this.chargeActive = false;
                this.chargeDuration = 0;
            } else if (faction === 'nurgle') {
                this.plagueCooldown = 400;
                this.spawnPlaguePool = false;
            } else if (faction === 'tzeentch') {
                this.warpCooldown = 180;
                this.spawnWarpBolts = false;
                this.warpAngle = 0;
            }
        }
    }

    takeDamage(amount) {
        if (this.dead) return;
        this.health -= amount;
        this.stagger = 5;
        if (this.health <= 0) {
            this.dead = true;
            this.deathTimer = 30;
        }
    }

    update(player, scene, time) {
        if (this.dead) {
            this.deathTimer--;
            return this.deathTimer > 0;
        }
        if (this.stagger > 0) {
            this.stagger--;
            return true;
        }

        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (this.rank === 'demon') {
            if (this.faction === 'khorne') {
                this.chargeCooldown--;
                if (this.chargeCooldown <= 0 && dist > 60 && dist < 250) {
                    this.chargeActive = true;
                    this.chargeDuration = 45;
                    this.chargeCooldown = 300;
                }
                if (this.chargeActive) {
                    this.chargeDuration--;
                    if (this.chargeDuration <= 0) this.chargeActive = false;
                }
            } else if (this.faction === 'nurgle') {
                this.plagueCooldown--;
                if (this.plagueCooldown <= 0 && dist < 120) {
                    this.spawnPlaguePool = true;
                    this.plagueCooldown = 400;
                }
            } else if (this.faction === 'tzeentch') {
                this.warpCooldown--;
                if (this.warpCooldown <= 0 && dist > 80 && dist < 300) {
                    this.spawnWarpBolts = true;
                    this.warpAngle = Math.atan2(dy, dx);
                    this.warpCooldown = 180;
                }
            } else if (this.faction === 'slaanesh') {
                // 色孽恶魔：大范围魅惑减速
                if (dist < 200) {
                    player.slaaneshSlow = 0.5;
                }
            }
        } else if (this.faction === 'slaanesh') {
            // 色孽小怪：近距离魅惑减速
            if (dist < 100) {
                player.slaaneshSlow = 0.7;
            }
        }

        // 远程爆弹攻击（奸奇使用warp bolts，在此处不处理）
        if (this.faction !== 'tzeentch') {
            this.boltCooldown--;
            if (dist > 80 && dist < 400 && this.boltCooldown <= 0) {
                this.spawnBolt = true;
                this.boltAngle = Math.atan2(dy, dx);
                this.boltCooldown = this.attackInterval * 1.5;
            }
        }

        let moveSpeed = this.speed;
        if (this.chargeActive) moveSpeed *= 3.5;
        const jitter = Math.sin(time * 0.1 + this.walkOffset) * 0.3;
        const angle = Math.atan2(dy, dx) + jitter;
        const nx = this.x + Math.cos(angle) * moveSpeed;
        const ny = this.y + Math.sin(angle) * moveSpeed;
        const resolved = scene.resolveCollision(nx, ny, this.radius, this.x, this.y);
        this.x = resolved.x;
        this.y = resolved.y;

        if (dist < this.radius + player.radius + 5) {
            this.attackCooldown--;
            if (this.attackCooldown <= 0) {
                player.takeDamage(this.damage);
                this.attackCooldown = this.attackInterval;
            }
        }

        return true;
    }

    draw(ctx) {
        if (this.dead) {
            const alpha = this.deathTimer / 30;
            ctx.globalAlpha = alpha;
        }
        const f = FACTIONS[this.faction];
        const isDemon = this.rank === 'demon';
        const baseColor = isDemon ? f.dColor : f.color;
        const armorDark = isDemon ? '#1a0505' : '#1a1a1a';

        ctx.save();
        ctx.translate(this.x, this.y);

        // 色孽魅惑光环
        if (isDemon && this.faction === 'slaanesh' && !this.dead) {
            ctx.globalAlpha = 0.12 + Math.sin(Date.now() * 0.003) * 0.04;
            ctx.fillStyle = '#9a4a9a';
            ctx.beginPath();
            ctx.arc(0, 0, 150, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = this.dead ? (this.deathTimer / 30) : 1.0;
        }

        // 恐虐冲锋血光
        if (isDemon && this.faction === 'khorne' && this.chargeActive) {
            ctx.shadowColor = '#ff0000';
            ctx.shadowBlur = 20;
        }

        if (isDemon) {
            // ========== 混沌大魔绘制 ==========
            // 翅膀（恐虐/色孽）
            if (this.faction === 'khorne' || this.faction === 'slaanesh') {
                ctx.fillStyle = baseColor;
                ctx.globalAlpha = 0.4;
                ctx.beginPath();
                ctx.moveTo(-8, -5);
                ctx.quadraticCurveTo(-35, -25, -40, -5);
                ctx.quadraticCurveTo(-30, 10, -8, 5);
                ctx.fill();
                ctx.beginPath();
                ctx.moveTo(8, -5);
                ctx.quadraticCurveTo(35, -25, 40, -5);
                ctx.quadraticCurveTo(30, 10, 8, 5);
                ctx.fill();
                ctx.globalAlpha = this.dead ? (this.deathTimer / 30) : 1.0;
            }

            // 主体（更大更不规则）
            ctx.fillStyle = baseColor;
            ctx.beginPath();
            ctx.ellipse(0, 0, this.radius, this.radius * 1.1, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffaa00';
            ctx.lineWidth = 2;
            ctx.stroke();

            // 纳垢大魔：脓包和触手
            if (this.faction === 'nurgle') {
                ctx.fillStyle = '#7a9a3a';
                for (let i = 0; i < 5; i++) {
                    const a = (i / 5) * Math.PI * 2;
                    const dist = this.radius * 0.6 + Math.sin(Date.now() * 0.002 + i) * 2;
                    ctx.beginPath();
                    ctx.arc(Math.cos(a) * dist, Math.sin(a) * dist, 4 + Math.sin(i * 2) * 2, 0, Math.PI * 2);
                    ctx.fill();
                }
                // 触手
                ctx.strokeStyle = '#5a7a2a';
                ctx.lineWidth = 2;
                for (let i = 0; i < 3; i++) {
                    const a = (i / 3) * Math.PI * 2 + 0.5;
                    ctx.beginPath();
                    ctx.moveTo(Math.cos(a) * this.radius * 0.5, Math.sin(a) * this.radius * 0.5);
                    ctx.quadraticCurveTo(
                        Math.cos(a + 0.3) * this.radius * 1.2,
                        Math.sin(a + 0.3) * this.radius * 1.2,
                        Math.cos(a + 0.6) * this.radius * 0.8,
                        Math.sin(a + 0.6) * this.radius * 0.8
                    );
                    ctx.stroke();
                }
            }
            // 奸奇大魔：触手和多眼
            else if (this.faction === 'tzeentch') {
                ctx.fillStyle = '#6a9aea';
                for (let i = 0; i < 4; i++) {
                    const a = (i / 4) * Math.PI * 2 + Date.now() * 0.001;
                    ctx.beginPath();
                    ctx.arc(Math.cos(a) * this.radius * 0.5, Math.sin(a) * this.radius * 0.5, 3, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = '#ff0000';
                    ctx.beginPath();
                    ctx.arc(Math.cos(a) * this.radius * 0.5, Math.sin(a) * this.radius * 0.5, 1.5, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = '#6a9aea';
                }
                // 火焰光环
                ctx.strokeStyle = '#3a9aea';
                ctx.lineWidth = 1;
                for (let i = 0; i < 3; i++) {
                    ctx.beginPath();
                    ctx.arc(0, 0, this.radius + 5 + i * 4 + Math.sin(Date.now() * 0.005 + i) * 3, 0, Math.PI * 2);
                    ctx.stroke();
                }
            }
            // 恐虐大魔：角和链锯
            else if (this.faction === 'khorne') {
                // 巨大弯角
                ctx.fillStyle = '#ccaa00';
                ctx.beginPath();
                ctx.moveTo(-8, -this.radius + 2);
                ctx.quadraticCurveTo(-20, -this.radius - 15, -6, -this.radius - 20);
                ctx.quadraticCurveTo(-2, -this.radius - 10, -4, -this.radius + 2);
                ctx.fill();
                ctx.beginPath();
                ctx.moveTo(8, -this.radius + 2);
                ctx.quadraticCurveTo(20, -this.radius - 15, 6, -this.radius - 20);
                ctx.quadraticCurveTo(2, -this.radius - 10, 4, -this.radius + 2);
                ctx.fill();
                // 链锯剑
                ctx.fillStyle = '#555';
                ctx.fillRect(this.radius - 2, -3, 18, 5);
                ctx.fillStyle = '#aaa';
                for (let i = 0; i < 4; i++) {
                    ctx.fillRect(this.radius + i * 4, -3, 2, 5);
                }
            }
            // 色孽大魔：蛇尾和尖刺
            else if (this.faction === 'slaanesh') {
                ctx.strokeStyle = '#da6ada';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(0, this.radius);
                ctx.quadraticCurveTo(15, this.radius + 15, 0, this.radius + 25);
                ctx.quadraticCurveTo(-15, this.radius + 35, 0, this.radius + 40);
                ctx.stroke();
                // 尖刺
                ctx.fillStyle = '#ff88ff';
                for (let i = 0; i < 6; i++) {
                    const a = (i / 6) * Math.PI * 2;
                    ctx.beginPath();
                    ctx.moveTo(Math.cos(a) * this.radius, Math.sin(a) * this.radius);
                    ctx.lineTo(Math.cos(a) * (this.radius + 6), Math.sin(a) * (this.radius + 6) - 3);
                    ctx.lineTo(Math.cos(a) * (this.radius + 4), Math.sin(a) * (this.radius + 4));
                    ctx.fill();
                }
            }

            // 大魔通用：金色邪恶眼睛
            ctx.fillStyle = '#ffcc00';
            ctx.shadowColor = '#ffaa00';
            ctx.shadowBlur = 6;
            ctx.beginPath();
            ctx.arc(0, -this.radius * 0.3, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ff0000';
            ctx.beginPath();
            ctx.arc(0, -this.radius * 0.3, 2, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;

        } else {
            // ========== 混沌星际战士绘制 ==========
            // 动力背包
            ctx.fillStyle = armorDark;
            ctx.fillRect(-7, 8, 14, 10);

            // 主体动力甲
            ctx.fillStyle = baseColor;
            ctx.beginPath();
            ctx.ellipse(0, 0, this.radius, this.radius * 0.9, 0, 0, Math.PI * 2);
            ctx.fill();

            // 动力甲破损/锈迹效果
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.beginPath();
            ctx.arc(this.radius * 0.3, this.radius * 0.2, 3, 0, Math.PI * 2);
            ctx.fill();

            // 混沌肩甲（带尖刺）
            ctx.fillStyle = baseColor;
            ctx.beginPath();
            ctx.ellipse(-11, -6, 6, 7, -0.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#444';
            ctx.lineWidth = 1;
            ctx.stroke();
            // 肩甲尖刺
            ctx.fillStyle = '#666';
            ctx.beginPath();
            ctx.moveTo(-15, -10); ctx.lineTo(-13, -15); ctx.lineTo(-11, -10);
            ctx.closePath(); ctx.fill();

            ctx.fillStyle = baseColor;
            ctx.beginPath();
            ctx.ellipse(11, -6, 6, 7, 0.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#444';
            ctx.stroke();
            ctx.fillStyle = '#666';
            ctx.beginPath();
            ctx.moveTo(11, -10); ctx.lineTo(13, -15); ctx.lineTo(15, -10);
            ctx.closePath(); ctx.fill();

            // 头盔（带角）
            ctx.fillStyle = armorDark;
            ctx.beginPath();
            ctx.arc(0, -3, 8, 0, Math.PI * 2);
            ctx.fill();
            // 角
            ctx.fillStyle = '#888';
            ctx.beginPath();
            ctx.moveTo(-5, -8); ctx.lineTo(-7, -14); ctx.lineTo(-3, -9);
            ctx.closePath(); ctx.fill();
            ctx.beginPath();
            ctx.moveTo(5, -8); ctx.lineTo(7, -14); ctx.lineTo(3, -9);
            ctx.closePath(); ctx.fill();

            // 邪恶目镜
            ctx.fillStyle = '#ff3300';
            ctx.shadowColor = '#ff0000';
            ctx.shadowBlur = 3;
            ctx.fillRect(-4, -5, 3, 2);
            ctx.fillRect(1, -5, 3, 2);
            ctx.shadowBlur = 0;

            // 呼吸格栅
            ctx.fillStyle = '#222';
            ctx.fillRect(-2.5, 0, 5, 2.5);

            // 阵营混沌符号
            if (this.faction === 'khorne') {
                ctx.strokeStyle = '#ff0000';
                ctx.lineWidth = 1.5;
                ctx.beginPath();
                ctx.moveTo(0, 2); ctx.lineTo(0, 8);
                ctx.moveTo(-3, 4); ctx.lineTo(3, 4);
                ctx.moveTo(-2, 3); ctx.lineTo(-4, 1);
                ctx.moveTo(2, 3); ctx.lineTo(4, 1);
                ctx.stroke();
            } else if (this.faction === 'nurgle') {
                ctx.fillStyle = '#8a9a4a';
                ctx.beginPath();
                ctx.arc(0, 5, 3, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = '#5a7a2a';
                ctx.beginPath(); ctx.arc(-1, 4, 1, 0, Math.PI * 2); ctx.fill();
            } else if (this.faction === 'tzeentch') {
                ctx.strokeStyle = '#5aaaea';
                ctx.lineWidth = 1.5;
                ctx.beginPath();
                ctx.arc(0, 5, 3, 0, Math.PI * 2);
                ctx.stroke();
                ctx.beginPath(); ctx.moveTo(0, 2); ctx.lineTo(0, 8);
                ctx.moveTo(-2, 3); ctx.lineTo(2, 7);
                ctx.moveTo(2, 3); ctx.lineTo(-2, 7);
                ctx.stroke();
            } else if (this.faction === 'slaanesh') {
                ctx.strokeStyle = '#da6ada';
                ctx.lineWidth = 1.5;
                ctx.beginPath();
                ctx.moveTo(0, 2); ctx.quadraticCurveTo(4, 5, 0, 8);
                ctx.quadraticCurveTo(-4, 5, 0, 2);
                ctx.stroke();
            }

            // 混沌武器
            ctx.fillStyle = '#333';
            ctx.fillRect(this.radius - 1, -3, 14, 4);
            ctx.fillStyle = '#555';
            ctx.fillRect(this.radius + 2, -4, 3, 1);
            ctx.fillRect(this.radius + 6, -4, 3, 1);
        }

        ctx.shadowBlur = 0;
        ctx.restore();
        ctx.globalAlpha = 1.0;

        if (!this.dead) {
            const barW = isDemon ? 32 : 24;
            const barH = isDemon ? 5 : 4;
            const bx = this.x - barW / 2;
            const by = this.y - this.radius - 12;
            ctx.fillStyle = '#111';
            ctx.fillRect(bx - 1, by - 1, barW + 2, barH + 2);
            ctx.fillStyle = '#333';
            ctx.fillRect(bx, by, barW, barH);
            ctx.fillStyle = baseColor;
            ctx.fillRect(bx, by, barW * (this.health / this.maxHealth), barH);
            if (isDemon) {
                ctx.strokeStyle = '#ffaa00';
                ctx.lineWidth = 1;
                ctx.strokeRect(bx - 1, by - 1, barW + 2, barH + 2);
            }
        }
    }
}

// ============================================================
// 地面持续效果（毒池等）
// ============================================================
class GroundEffect {
    constructor(x, y, type, radius, duration, damage) {
        this.x = x; this.y = y; this.type = type;
        this.radius = radius; this.duration = duration;
        this.maxDuration = duration; this.damage = damage;
    }
    update() { this.duration--; return this.duration > 0; }
    draw(ctx) {
        const alpha = Math.min(0.6, (this.duration / this.maxDuration) * 0.6);
        ctx.save();
        ctx.globalAlpha = alpha;
        if (this.type === 'plague') {
            ctx.fillStyle = '#4a7a2a';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#7a9a4a'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius * 0.7, 0, Math.PI * 2); ctx.stroke();
            ctx.fillStyle = '#6a9a3a';
            ctx.beginPath(); ctx.arc(this.x + 8, this.y - 5, 6, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(this.x - 10, this.y + 8, 5, 0, Math.PI * 2); ctx.fill();
        }
        ctx.restore();
    }
}

// ============================================================
// 敌人投射物（灵能弹等）
// ============================================================
class EnemyProjectile {
    constructor(x, y, angle, speed, damage, faction, type = 'warp') {
        this.x = x; this.y = y;
        this.vx = Math.cos(angle) * speed;
        this.vy = Math.sin(angle) * speed;
        this.speed = speed;
        this.damage = damage;
        this.faction = faction;
        this.type = type;
        this.radius = type === 'bolt' ? 4 : 5;
        this.life = 120;
        this.angle = angle;
    }
    update(scene) {
        this.x += this.vx; this.y += this.vy;
        this.life--;
        if (this.x < 0 || this.x > scene.w || this.y < 0 || this.y > scene.h) return false;
        for (const obs of scene.obstacles) {
            const closestX = Math.max(obs.x, Math.min(this.x, obs.x + obs.w));
            const closestY = Math.max(obs.y, Math.min(this.y, obs.y + obs.h));
            const dx = this.x - closestX;
            const dy = this.y - closestY;
            if (dx * dx + dy * dy < this.radius * this.radius) return false;
        }
        return this.life > 0;
    }
    draw(ctx) {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);
        if (this.type === 'bolt') {
            // 爆弹：红色曳光弹
            ctx.shadowColor = '#ff4400';
            ctx.shadowBlur = 6;
            ctx.fillStyle = '#cc2200';
            ctx.beginPath(); ctx.ellipse(0, 0, 6, 2.5, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ff8844';
            ctx.beginPath(); ctx.arc(0, 0, 2, 0, Math.PI * 2); ctx.fill();
        } else {
            // 奸奇灵能弹：蓝色
            ctx.shadowColor = '#00ffff';
            ctx.shadowBlur = 8;
            ctx.fillStyle = '#3a9aea';
            ctx.beginPath(); ctx.ellipse(0, 0, 8, 3, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#a0e0ff';
            ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.fill();
        }
        ctx.shadowBlur = 0;
        ctx.restore();
    }
}

// ============================================================
// 输入管理
// ============================================================
class InputManager {
    constructor(canvas) {
        this.keys = {};
        this.mouseX = 0;
        this.mouseY = 0;
        this.mouseDown = false;
        this.canvas = canvas;

        document.addEventListener('keydown', e => {
            this.keys[e.key] = true;
            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
                e.preventDefault();
            }
        });
        document.addEventListener('keyup', e => {
            this.keys[e.key] = false;
        });
        window.addEventListener('blur', () => {
            this.keys = {};
            this.mouseDown = false;
        });

        canvas.addEventListener('mousemove', e => {
            const rect = canvas.getBoundingClientRect();
            this.mouseX = (e.clientX - rect.left) * (canvas.width / rect.width);
            this.mouseY = (e.clientY - rect.top) * (canvas.height / rect.height);
        });

        canvas.addEventListener('mousedown', () => this.mouseDown = true);
        canvas.addEventListener('mouseup', () => this.mouseDown = false);
    }
}

// ============================================================
// 弹药空投
// ============================================================
class AmmoDrop {
    constructor(x, y, amount = 60) {
        this.x = x;
        this.y = y;
        this.amount = amount;
        this.radius = 12;
        this.life = 600;
        this.pulse = 0;
    }

    update() {
        this.life--;
        this.pulse += 0.08;
        return this.life > 0;
    }

    draw(ctx) {
        const glow = 0.5 + Math.sin(this.pulse) * 0.3;
        ctx.save();
        ctx.shadowColor = '#c4a000';
        ctx.shadowBlur = 8 + glow * 6;
        ctx.fillStyle = '#2a2010';
        ctx.strokeStyle = '#c4a000';
        ctx.lineWidth = 2;
        ctx.fillRect(this.x - 10, this.y - 8, 20, 16);
        ctx.strokeRect(this.x - 10, this.y - 8, 20, 16);
        ctx.fillStyle = '#c4a000';
        ctx.beginPath(); ctx.arc(this.x - 7, this.y - 5, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(this.x + 7, this.y - 5, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(this.x - 7, this.y + 5, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(this.x + 7, this.y + 5, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#c4a000';
        ctx.fillRect(this.x - 3, this.y - 4, 2, 8);
        ctx.fillRect(this.x + 1, this.y - 4, 2, 8);
        ctx.shadowBlur = 0;
        if (this.life > 540 || this.life < 60) {
            ctx.globalAlpha = (this.life > 540) ? (this.life - 540) / 60 : this.life / 60;
        } else {
            ctx.globalAlpha = 0.7;
        }
        ctx.fillStyle = '#c4a000';
        ctx.font = 'bold 11px Georgia';
        ctx.textAlign = 'center';
        ctx.fillText(`+${this.amount}`, this.x, this.y - 14);
        ctx.restore();
    }
}

// ============================================================
// 血药空投
// ============================================================
class HealthPack {
    constructor(x, y, healPercent = 15) {
        this.x = x;
        this.y = y;
        this.healPercent = healPercent;
        this.radius = 12;
        this.life = 600;
        this.pulse = 0;
    }

    update() {
        this.life--;
        this.pulse += 0.08;
        return this.life > 0;
    }

    draw(ctx) {
        const glow = 0.5 + Math.sin(this.pulse) * 0.3;
        ctx.save();
        ctx.shadowColor = '#cc2222';
        ctx.shadowBlur = 8 + glow * 6;
        ctx.fillStyle = '#2a1010';
        ctx.strokeStyle = '#cc2222';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(this.x, this.y, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#cc2222';
        ctx.fillRect(this.x - 2, this.y - 7, 4, 14);
        ctx.fillRect(this.x - 7, this.y - 2, 14, 4);
        ctx.shadowBlur = 0;
        if (this.life > 540 || this.life < 60) {
            ctx.globalAlpha = (this.life > 540) ? (this.life - 540) / 60 : this.life / 60;
        } else {
            ctx.globalAlpha = 0.7;
        }
        ctx.fillStyle = '#cc2222';
        ctx.font = 'bold 11px Georgia';
        ctx.textAlign = 'center';
        ctx.fillText(`+${this.healPercent}%`, this.x, this.y - 16);
        ctx.restore();
    }
}

// ============================================================
// 强化道具箱（爆弹强化）
// ============================================================
class PowerUpCrate {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 14;
        this.life = 900;
        this.pulse = 0;
        this.bonusAmmo = 30;
    }

    update() {
        this.life--;
        this.pulse += 0.1;
        return this.life > 0;
    }

    draw(ctx) {
        const glow = 0.5 + Math.sin(this.pulse) * 0.3;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.pulse * 0.05);

        // 发光外圈
        ctx.shadowColor = '#ff6600';
        ctx.shadowBlur = 10 + glow * 8;

        // 箱子主体（金色六边形）
        ctx.fillStyle = '#2a1a0a';
        ctx.strokeStyle = '#ffaa00';
        ctx.lineWidth = 3;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2 - Math.PI / 2;
            const r = 14;
            const px = Math.cos(angle) * r;
            const py = Math.sin(angle) * r;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // 内部装饰
        ctx.fillStyle = '#ff6600';
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();

        // 闪电符号
        ctx.strokeStyle = '#ffcc00';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-3, -6); ctx.lineTo(2, 0); ctx.lineTo(-2, 0); ctx.lineTo(3, 6);
        ctx.stroke();

        ctx.shadowBlur = 0;
        ctx.restore();

        // 浮动文字
        ctx.save();
        if (this.life > 840 || this.life < 60) {
            ctx.globalAlpha = (this.life > 840) ? (this.life - 840) / 60 : this.life / 60;
        }
        ctx.fillStyle = '#ffaa00';
        ctx.font = 'bold 12px Georgia';
        ctx.textAlign = 'center';
        ctx.fillText(`+${this.bonusAmmo}发`, this.x, this.y - 20);
        ctx.restore();
    }
}

// ============================================================
// 极限战士战斗兄弟（濒死救援）
// ============================================================
class BattleBrother {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 16;
        this.speed = 3;
        this.angle = 0;
        this.life = 360; // 6秒存在时间
        this.shootCooldown = 0;
        this.kills = 0;
        this.maxKills = 4;
        this.leaving = false;
        this.leaveTarget = null;
    }

    update(enemies, scene) {
        if (this.leaving) {
            // 离开战场
            const dx = this.leaveTarget.x - this.x;
            const dy = this.leaveTarget.y - this.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 5) return false;
            this.angle = Math.atan2(dy, dx);
            this.x += (dx / dist) * this.speed * 2;
            this.y += (dy / dist) * this.speed * 2;
            return true;
        }

        // 寻找最近敌人
        let nearest = null;
        let minDist = Infinity;
        for (const enemy of enemies) {
            if (enemy.dead) continue;
            const dx = enemy.x - this.x;
            const dy = enemy.y - this.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < minDist) {
                minDist = dist;
                nearest = enemy;
            }
        }

        if (nearest) {
            const dx = nearest.x - this.x;
            const dy = nearest.y - this.y;
            this.angle = Math.atan2(dy, dx);
            if (minDist > 120) {
                const dist = Math.sqrt(dx * dx + dy * dy);
                const nx = this.x + (dx / dist) * this.speed;
                const ny = this.y + (dy / dist) * this.speed;
                const resolved = scene.resolveCollision(nx, ny, this.radius, this.x, this.y);
                this.x = resolved.x;
                this.y = resolved.y;
            }
            if (this.shootCooldown <= 0 && minDist < 400) {
                this.shootCooldown = 8;
                return { type: 'shoot', angle: this.angle, x: this.x, y: this.y };
            }
        }

        if (this.shootCooldown > 0) this.shootCooldown--;
        this.life--;

        // 达到击杀数或时间到，开始离开
        if (this.kills >= this.maxKills || this.life <= 0) {
            this.leaving = true;
            // 找到最近的地图边缘
            const edges = [
                { x: this.x, y: -50 },
                { x: this.x, y: scene.h + 50 },
                { x: -50, y: this.y },
                { x: scene.w + 50, y: this.y }
            ];
            let bestEdge = edges[0];
            let bestDist = Infinity;
            for (const edge of edges) {
                const dx = edge.x - this.x;
                const dy = edge.y - this.y;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < bestDist) {
                    bestDist = d;
                    bestEdge = edge;
                }
            }
            this.leaveTarget = bestEdge;
        }

        return true;
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);

        // 动力背包
        ctx.fillStyle = '#1a3a6a';
        ctx.fillRect(-8, 8, 16, 10);
        ctx.fillStyle = '#0d2850';
        ctx.fillRect(-6, 10, 12, 6);

        // 主体动力甲（深蓝色）
        ctx.fillStyle = '#0a3a8a';
        ctx.beginPath();
        ctx.ellipse(0, 0, this.radius, this.radius * 0.9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 2;
        ctx.stroke();

        // 肩甲
        ctx.fillStyle = '#0a3a8a';
        ctx.beginPath();
        ctx.ellipse(-12, -6, 6, 7, -0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#d4af37';
        ctx.stroke();
        ctx.beginPath();
        ctx.ellipse(12, -6, 6, 7, 0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // 头盔
        ctx.fillStyle = '#0d4088';
        ctx.beginPath();
        ctx.arc(0, -3, 7, 0, Math.PI * 2);
        ctx.fill();

        // 目镜（绿色发光）
        ctx.fillStyle = '#00cc44';
        ctx.shadowColor = '#00ff66';
        ctx.shadowBlur = 5;
        ctx.fillRect(-4, -4, 3, 2);
        ctx.fillRect(1, -4, 3, 2);
        ctx.shadowBlur = 0;

        // 爆矢枪
        ctx.fillStyle = '#2a2a2a';
        ctx.fillRect(10, -4, 16, 6);
        ctx.fillStyle = '#444';
        ctx.fillRect(24, -3, 6, 3);

        ctx.restore();
    }
}

// ============================================================
// 波次管理
// ============================================================
class WaveManager {
    constructor() {
        this.wave = 1;
        this.enemiesAlive = 0;
        this.enemiesToSpawn = 0;
        this.spawnInterval = 0;
        this.waveTimer = 0;
        this.betweenWaves = true;
        this.startNextWave();
    }

    startNextWave() {
        this.wave++;
        this.enemiesToSpawn = 5 + Math.floor(this.wave * 2.5);
        this.enemiesAlive = this.enemiesToSpawn;
        this.spawnInterval = Math.max(30, 90 - this.wave * 3);
        this.waveTimer = 0;
        this.betweenWaves = false;
    }

    update(spawnCallback) {
        if (this.betweenWaves) {
            this.waveTimer--;
            if (this.waveTimer <= 0) this.startNextWave();
            return;
        }
        this.waveTimer++;
        if (this.waveTimer >= this.spawnInterval && this.enemiesToSpawn > 0) {
            this.waveTimer = 0;
            this.enemiesToSpawn--;
            spawnCallback();
        }
        if (this.enemiesAlive <= 0 && this.enemiesToSpawn <= 0) {
            this.betweenWaves = true;
            this.waveTimer = 300;
        }
    }

    enemyDefeated() {
        this.enemiesAlive--;
    }
}

// ============================================================
// 浮动文字
// ============================================================
class FloatingText {
    constructor(x, y, text, color) {
        this.x = x;
        this.y = y;
        this.text = text;
        this.color = color;
        this.life = 60;
        this.vy = -1.5;
    }

    update() {
        this.y += this.vy;
        this.life--;
        return this.life > 0;
    }

    draw(ctx) {
        ctx.globalAlpha = Math.max(0, this.life / 60);
        ctx.fillStyle = this.color;
        ctx.font = 'bold 14px Georgia';
        ctx.textAlign = 'center';
        ctx.fillText(this.text, this.x, this.y);
        ctx.globalAlpha = 1.0;
    }
}

// ============================================================
// 主游戏引擎
// ============================================================
class Game {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.input = new InputManager(this.canvas);
        this.audio = new AudioEngine();
        this.particles = new ParticleSystem();
        this.scene = new Scene(1280, 720);
        this.player = new Player(640, 360);
        this.bullets = [];
        this.enemies = [];
        this.ammoDrops = [];
        this.healthPacks = [];
        this.powerUpCrates = [];
        this.groundEffects = [];
        this.enemyProjectiles = [];
        this.floatingTexts = [];
        this.battleBrother = null;
        this.waveManager = new WaveManager();
        this.score = 0;
        this.gameTime = 0;
        this.state = 'menu';
        this.lastTime = 0;
        this.accumulator = 0;
        this.step = 1000 / 60;

        this.bindEvents();
        this.resize();
        window.addEventListener('resize', () => this.resize());
    }

    resize() {
        const container = document.getElementById('game-container');
        const scale = Math.min(window.innerWidth / 1280, window.innerHeight / 720) * 0.95;
        container.style.transform = `scale(${scale})`;
    }

    bindEvents() {
        document.getElementById('start-btn').addEventListener('click', () => this.start());
        document.getElementById('restart-btn').addEventListener('click', () => this.restart());
        document.addEventListener('keydown', e => {
            if (e.key === 'r' || e.key === 'R') {
                if (this.state === 'playing') this.player.startReload();
            }
            if (e.key === ' ') {
                if (this.state === 'playing') this.player.startMelee();
            }
            if (e.key === 'e' || e.key === 'E') {
                if (this.state === 'playing') this.player.startSkill();
            }
        });
    }

    start() {
        document.getElementById('start-screen').style.display = 'none';
        document.getElementById('hud').style.display = 'block';
        this.state = 'playing';
        this.lastTime = performance.now();
        requestAnimationFrame(t => this.loop(t));
    }

    restart() {
        document.getElementById('game-over-screen').style.display = 'none';
        this.player = new Player(640, 360);
        this.bullets = [];
        this.enemies = [];
        this.ammoDrops = [];
        this.healthPacks = [];
        this.powerUpCrates = [];
        this.groundEffects = [];
        this.enemyProjectiles = [];
        this.floatingTexts = [];
        this.battleBrother = null;
        this.waveManager = new WaveManager();
        this.score = 0;
        this.gameTime = 0;
        this.state = 'playing';
        this.lastTime = performance.now();
        requestAnimationFrame(t => this.loop(t));
    }

    loop(timestamp) {
        if (this.state !== 'playing' && this.state !== 'gameover') return;
        this.accumulator += timestamp - this.lastTime;
        this.lastTime = timestamp;
        while (this.accumulator >= this.step) {
            this.update();
            this.accumulator -= this.step;
        }
        this.draw();
        if (this.state === 'playing') {
            requestAnimationFrame(t => this.loop(t));
        }
    }

    spawnEnemy() {
        const side = Math.floor(Math.random() * 4);
        let x, y;
        const margin = 30;
        switch (side) {
            case 0: x = margin; y = Math.random() * this.canvas.height; break;
            case 1: x = this.canvas.width - margin; y = Math.random() * this.canvas.height; break;
            case 2: x = Math.random() * this.canvas.width; y = margin; break;
            case 3: x = Math.random() * this.canvas.width; y = this.canvas.height - margin; break;
        }
        const factions = ['khorne', 'nurgle', 'tzeentch', 'slaanesh'];
        const faction = factions[Math.floor(Math.random() * factions.length)];
        const demonChance = Math.min(0.05 + this.waveManager.wave * 0.025, 0.4);
        const rank = Math.random() < demonChance ? 'demon' : 'minion';
        const enemy = new Enemy(x, y, faction, rank);
        this.enemies.push(enemy);
        if (Math.random() < 0.3) this.audio.playEnemyRoar();
    }

    _getSafeDropPosition(x, y, radius = 12) {
        // 如果当前位置不在障碍物内，直接返回
        if (!this.scene.isBlocked(x, y, radius)) return { x, y };
        // 在周围螺旋搜索安全位置
        for (let dist = 10; dist <= 100; dist += 10) {
            for (let i = 0; i < 8; i++) {
                const angle = (i / 8) * Math.PI * 2;
                const nx = x + Math.cos(angle) * dist;
                const ny = y + Math.sin(angle) * dist;
                if (!this.scene.isBlocked(nx, ny, radius)) {
                    return { x: nx, y: ny };
                }
            }
        }
        // 实在找不到就在原地（最少不会卡在墙里出不来）
        return { x, y };
    }

    _onEnemyKilled(enemy) {
        const points = enemy.rank === 'demon' ? 150 : 50;
        this.score += points;
        this.particles.spawnDeathExplosion(enemy.x, enemy.y);
        this.audio.playDeath();
        this.floatingTexts.push(new FloatingText(enemy.x, enemy.y - 20, `+${points}`, '#c4a000'));
        if (Math.random() < 0.15) {
            const pos = this._getSafeDropPosition(enemy.x, enemy.y);
            this.ammoDrops.push(new AmmoDrop(pos.x, pos.y, 60));
        }
        if (enemy.rank === 'demon' && Math.random() < 0.2) {
            const pos = this._getSafeDropPosition(enemy.x, enemy.y);
            this.healthPacks.push(new HealthPack(pos.x, pos.y, 15));
        }
    }

    _spawnBattleBrother() {
        // 从玩家最近的地图边缘生成
        const edges = [
            { x: this.player.x, y: -40 },
            { x: this.player.x, y: this.scene.h + 40 },
            { x: -40, y: this.player.y },
            { x: this.scene.w + 40, y: this.player.y }
        ];
        let bestEdge = edges[0];
        let bestDist = Infinity;
        for (const edge of edges) {
            const dx = edge.x - this.player.x;
            const dy = edge.y - this.player.y;
            const d = Math.sqrt(dx * dx + dy * dy);
            if (d < bestDist) {
                bestDist = d;
                bestEdge = edge;
            }
        }
        this.battleBrother = new BattleBrother(bestEdge.x, bestEdge.y);
        this.audio.playGunshot();
        this.audio.playGunshot();
        // 传送特效
        for (let i = 0; i < 20; i++) {
            const a = (i / 20) * Math.PI * 2;
            const speed = 2 + Math.random() * 3;
            this.particles.particles.push({
                x: bestEdge.x, y: bestEdge.y,
                vx: Math.cos(a) * speed,
                vy: Math.sin(a) * speed,
                life: 1.0, decay: 0.02 + Math.random() * 0.02,
                size: 2 + Math.random() * 4,
                color: `hsl(${120 + Math.random() * 40}, 100%, ${50 + Math.random() * 30}%)`,
                type: 'fire'
            });
        }
    }

    update() {
        if (this.state !== 'playing') return;
        this.gameTime++;
        this.player.update(this.input, this.scene);

        if (this.input.mouseDown && this.player.shootCooldown <= 0 && !this.player.reloading && this.player.ammo > 0) {
            this.shoot();
        }
        if (this.player.ammo <= 0 && !this.player.reloading && this.player.reserveAmmo > 0) {
            this.player.startReload();
        }

        for (let i = this.bullets.length - 1; i >= 0; i--) {
            if (!this.bullets[i].update(this.scene)) this.bullets.splice(i, 1);
        }

        for (let i = this.enemies.length - 1; i >= 0; i--) {
            const enemy = this.enemies[i];
            const alive = enemy.update(this.player, this.scene, this.gameTime);
            if (!alive) {
                this.enemies.splice(i, 1);
                if (enemy.dead) this.waveManager.enemyDefeated();
                continue;
            }

            // 玩家与敌人碰撞排斥，防止重合卡住
            const pdx = this.player.x - enemy.x;
            const pdy = this.player.y - enemy.y;
            const pDist = Math.sqrt(pdx * pdx + pdy * pdy);
            const minDist = this.player.radius + enemy.radius;
            if (pDist < minDist && pDist > 0) {
                const overlap = minDist - pDist;
                const pushX = (pdx / pDist) * overlap * 0.6;
                const pushY = (pdy / pDist) * overlap * 0.6;
                enemy.x -= pushX;
                enemy.y -= pushY;
            }

            if (enemy.spawnPlaguePool) {
                enemy.spawnPlaguePool = false;
                this.groundEffects.push(new GroundEffect(enemy.x, enemy.y, 'plague', 70, 600, 8));
                for (let k = 0; k < 15; k++) {
                    const a = Math.random() * Math.PI * 2;
                    const sp = 1 + Math.random() * 3;
                    this.particles.particles.push({
                        x: enemy.x, y: enemy.y,
                        vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
                        life: 1.0, decay: 0.015 + Math.random() * 0.015,
                        size: 3 + Math.random() * 6,
                        color: `hsl(${80 + Math.random() * 40}, 70%, ${30 + Math.random() * 20}%)`,
                        type: 'smoke'
                    });
                }
            }
            if (enemy.chargeActive) {
                for (let k = 0; k < 3; k++) {
                    const ox = (Math.random() - 0.5) * 10;
                    const oy = (Math.random() - 0.5) * 10;
                    this.particles.particles.push({
                        x: enemy.x + ox, y: enemy.y + oy,
                        vx: (Math.random() - 0.5) * 1.5,
                        vy: (Math.random() - 0.5) * 1.5,
                        life: 1.0, decay: 0.03 + Math.random() * 0.02,
                        size: 2 + Math.random() * 4,
                        color: `hsl(${0 + Math.random() * 15}, 100%, ${40 + Math.random() * 30}%)`,
                        type: 'blood'
                    });
                }
            }
            if (enemy.spawnWarpBolts) {
                enemy.spawnWarpBolts = false;
                for (let b = -1; b <= 1; b++) {
                    const angle = enemy.warpAngle + b * 0.25;
                    this.enemyProjectiles.push(new EnemyProjectile(enemy.x, enemy.y, angle, 4, 15, 'tzeentch'));
                }
            }
            if (enemy.spawnBolt) {
                enemy.spawnBolt = false;
                const boltDmg = Math.max(3, Math.floor(enemy.damage * 0.5));
                const boltSpeed = enemy.rank === 'demon' ? 5 : 4;
                this.enemyProjectiles.push(new EnemyProjectile(enemy.x, enemy.y, enemy.boltAngle, boltSpeed, boltDmg, enemy.faction, 'bolt'));
            }

            for (let j = this.bullets.length - 1; j >= 0; j--) {
                const bullet = this.bullets[j];
                const dx = bullet.x - enemy.x;
                const dy = bullet.y - enemy.y;
                if (dx * dx + dy * dy < (bullet.radius + enemy.radius) * (bullet.radius + enemy.radius)) {
                    enemy.takeDamage(bullet.damage);
                    this.particles.spawnBlood(bullet.x, bullet.y, enemy.rank === 'demon' ? 0.5 : 0.3);
                    this.bullets.splice(j, 1);
                    if (enemy.dead) {
                        this._onEnemyKilled(enemy);
                    }
                    break;
                }
            }

        }

        // 近战伤害判定（仅在justMelee触发的那一帧执行一次）
        if (this.player.justMelee) {
            this.audio.playMelee();
            const meleeBox = this.player.getMeleeHitbox();
            if (meleeBox) {
                for (const enemy of this.enemies) {
                    if (enemy.dead) continue;
                    const dx = enemy.x - meleeBox.x;
                    const dy = enemy.y - meleeBox.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < meleeBox.radius) {
                        const angle = Math.atan2(dy, dx);
                        // 处理角度环绕
                        let a = angle - meleeBox.startAngle;
                        while (a < 0) a += Math.PI * 2;
                        while (a > Math.PI * 2) a -= Math.PI * 2;
                        let range = meleeBox.endAngle - meleeBox.startAngle;
                        while (range < 0) range += Math.PI * 2;
                        if (a <= range) {
                            enemy.takeDamage(50);
                            this.audio.playHit();
                            this.particles.spawnBlood(enemy.x, enemy.y, 0.5);
                            if (enemy.dead) {
                                this._onEnemyKilled(enemy);
                            }
                        }
                    }
                }
            }
        }

        // 技能伤害判定（仅在justSkill触发的那一帧执行一次）
        if (this.player.justSkill) {
            this.audio.playSkillSwing();
            const skillRange = this.player.skillRange;
            for (const enemy of this.enemies) {
                if (enemy.dead) continue;
                const dx = enemy.x - this.player.x;
                const dy = enemy.y - this.player.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < skillRange) {
                    enemy.takeDamage(this.player.skillDamage);
                    this.particles.spawnBlood(enemy.x, enemy.y, 0.8);
                    if (enemy.dead) {
                        this._onEnemyKilled(enemy);
                    }
                }
            }
            for (let k = 0; k < 40; k++) {
                const a = Math.random() * Math.PI * 2;
                const r = Math.random() * skillRange;
                const sx = this.player.x + Math.cos(a) * r;
                const sy = this.player.y + Math.sin(a) * r;
                this.particles.particles.push({
                    x: sx, y: sy,
                    vx: Math.cos(a) * (1 + Math.random() * 2),
                    vy: Math.sin(a) * (1 + Math.random() * 2),
                    life: 1.0, decay: 0.03 + Math.random() * 0.02,
                    size: 2 + Math.random() * 5,
                    color: `hsl(${30 + Math.random() * 30}, 100%, ${50 + Math.random() * 30}%)`,
                    type: 'fire'
                });
            }
        }

        // 重置单次触发标志
        this.player.justMelee = false;
        this.player.justSkill = false;

        // 战斗兄弟AI
        if (this.battleBrother) {
            const action = this.battleBrother.update(this.enemies, this.scene);
            if (action && action.type === 'shoot') {
                const muzzle = {
                    x: this.battleBrother.x + Math.cos(action.angle) * (this.battleBrother.radius + 5),
                    y: this.battleBrother.y + Math.sin(action.angle) * (this.battleBrother.radius + 5)
                };
                // 战斗兄弟的子弹（绿色光效，伤害较高）
                const bbBullet = new Bullet(muzzle.x, muzzle.y, action.angle, true);
                bbBullet.damage = 45;
                bbBullet.radius = 6;
                this.bullets.push(bbBullet);
                this.audio.playGunshot();
            }
            // 检查战斗兄弟的子弹击杀
            for (const enemy of this.enemies) {
                if (enemy.dead) continue;
                const dx = enemy.x - this.battleBrother.x;
                const dy = enemy.y - this.battleBrother.y;
                if (dx * dx + dy * dy < (enemy.radius + this.battleBrother.radius) ** 2) {
                    // 战斗兄弟近战也能造成伤害
                    enemy.takeDamage(20);
                    if (enemy.dead) {
                        this._onEnemyKilled(enemy);
                    }
                }
            }
            if (!action) {
                // 战斗兄弟离开，播放消失特效
                for (let k = 0; k < 15; k++) {
                    const a = (k / 15) * Math.PI * 2;
                    const speed = 2 + Math.random() * 3;
                    this.particles.particles.push({
                        x: this.battleBrother.x, y: this.battleBrother.y,
                        vx: Math.cos(a) * speed,
                        vy: Math.sin(a) * speed,
                        life: 1.0, decay: 0.02 + Math.random() * 0.02,
                        size: 2 + Math.random() * 4,
                        color: `hsl(${120 + Math.random() * 40}, 100%, ${50 + Math.random() * 30}%)`,
                        type: 'fire'
                    });
                }
                this.battleBrother = null;
            }
        }

        for (let i = this.groundEffects.length - 1; i >= 0; i--) {
            const effect = this.groundEffects[i];
            if (!effect.update()) {
                this.groundEffects.splice(i, 1);
                continue;
            }
            if (effect.type === 'plague') {
                const dx = this.player.x - effect.x;
                const dy = this.player.y - effect.y;
                if (dx * dx + dy * dy < (this.player.radius + effect.radius) ** 2) {
                    if (this.gameTime % 30 === 0) {
                        this.player.takeDamage(effect.damage);
                    }
                }
            }
        }

        for (let i = this.enemyProjectiles.length - 1; i >= 0; i--) {
            const proj = this.enemyProjectiles[i];
            if (!proj.update(this.scene)) {
                this.enemyProjectiles.splice(i, 1);
                continue;
            }
            const dx = proj.x - this.player.x;
            const dy = proj.y - this.player.y;
            if (dx * dx + dy * dy < (proj.radius + this.player.radius) ** 2) {
                this.player.takeDamage(proj.damage);
                this.enemyProjectiles.splice(i, 1);
            }
        }

        for (let i = this.ammoDrops.length - 1; i >= 0; i--) {
            const drop = this.ammoDrops[i];
            if (!drop.update()) {
                this.ammoDrops.splice(i, 1);
                continue;
            }
            const dx = this.player.x - drop.x;
            const dy = this.player.y - drop.y;
            if (dx * dx + dy * dy < (this.player.radius + drop.radius) ** 2) {
                this.player.reserveAmmo += drop.amount;
                this.audio.playPickup();
                this.floatingTexts.push(new FloatingText(drop.x, drop.y - 15, `+${drop.amount} 弹药`, '#c4a000'));
                this.ammoDrops.splice(i, 1);
            }
        }

        for (let i = this.healthPacks.length - 1; i >= 0; i--) {
            const pack = this.healthPacks[i];
            if (!pack.update()) {
                this.healthPacks.splice(i, 1);
                continue;
            }
            const dx = this.player.x - pack.x;
            const dy = this.player.y - pack.y;
            if (dx * dx + dy * dy < (this.player.radius + pack.radius) ** 2) {
                const healAmount = Math.floor(this.player.maxHealth * pack.healPercent / 100);
                this.player.heal(healAmount);
                this.audio.playPickup();
                this.floatingTexts.push(new FloatingText(pack.x, pack.y - 15, `+${pack.healPercent}% 生命`, '#cc2222'));
                this.healthPacks.splice(i, 1);
            }
        }

        // 随机生成强化道具箱
        if (this.gameTime % 900 === 0 && this.gameTime > 0) {
            const margin = 100;
            let x = margin + Math.random() * (this.scene.w - margin * 2);
            let y = margin + Math.random() * (this.scene.h - margin * 2);
            const pos = this._getSafeDropPosition(x, y, 14);
            this.powerUpCrates.push(new PowerUpCrate(pos.x, pos.y));
        }

        // 强化道具箱拾取
        for (let i = this.powerUpCrates.length - 1; i >= 0; i--) {
            const crate = this.powerUpCrates[i];
            if (!crate.update()) {
                this.powerUpCrates.splice(i, 1);
                continue;
            }
            const dx = this.player.x - crate.x;
            const dy = this.player.y - crate.y;
            if (dx * dx + dy * dy < (this.player.radius + crate.radius) ** 2) {
                this.player.powerUpAmmo = crate.bonusAmmo;
                this.audio.playPickup();
                this.floatingTexts.push(new FloatingText(crate.x, crate.y - 20, `爆弹强化! ${crate.bonusAmmo}发`, '#ffaa00'));
                this.powerUpCrates.splice(i, 1);
            }
        }

        this.particles.update();

        for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
            if (!this.floatingTexts[i].update()) this.floatingTexts.splice(i, 1);
        }

        this.waveManager.update(() => this.spawnEnemy());

        // 濒死救援：第一次血量归零时触发
        if (this.player.health <= 0 && !this.player.usedRevive) {
            this.player.usedRevive = true;
            this.player.health = Math.floor(this.player.maxHealth * 0.1);
            this._spawnBattleBrother();
            this.floatingTexts.push(new FloatingText(this.player.x, this.player.y - 40, '为了帝皇! 战斗兄弟来了!', '#00cc44'));
        }

        if (this.player.health <= 0) {
            this.state = 'gameover';
            document.getElementById('final-score').textContent = this.score;
            document.getElementById('final-wave').textContent = this.waveManager.wave;
            document.getElementById('game-over-screen').style.display = 'flex';
        }

        this.updateUI();
    }

    shoot() {
        const muzzle = this.player.getMuzzlePosition();
        const isPowered = this.player.powerUpAmmo > 0;
        const bullet = new Bullet(muzzle.x, muzzle.y, this.player.angle, isPowered);
        this.bullets.push(bullet);
        this.player.ammo--;
        if (isPowered) {
            this.player.powerUpAmmo--;
            // 强化子弹音效（更响亮）
            this.audio.playPoweredShot();
        } else {
            this.audio.playGunshot();
        }
        this.player.shootCooldown = 7;
        this.particles.spawnMuzzleFlash(muzzle.x, muzzle.y, this.player.angle, isPowered);
    }

    updateUI() {
        document.getElementById('score-text').textContent = this.score;
        document.getElementById('wave-text').textContent = this.waveManager.wave;
        document.getElementById('health-fill').style.width = (this.player.health / this.player.maxHealth * 100) + '%';
        if (this.player.reloading) {
            document.getElementById('ammo-current').textContent = '换弹中';
            document.getElementById('ammo-total').textContent = '';
        } else if (this.player.powerUpAmmo > 0) {
            document.getElementById('ammo-current').textContent = this.player.ammo;
            document.getElementById('ammo-total').textContent = `强化:${this.player.powerUpAmmo}`;
        } else {
            document.getElementById('ammo-current').textContent = this.player.ammo;
            document.getElementById('ammo-total').textContent = this.player.reserveAmmo;
        }
        const skillPct = Math.max(0, 1 - this.player.skillCooldown / this.player.skillCooldownMax) * 100;
        document.getElementById('skill-fill').style.width = skillPct + '%';
        document.getElementById('skill-label').textContent = this.player.skillCooldown > 0 ? `充能: ${Math.ceil(skillPct)}%` : '技能就绪';
    }

    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.scene.draw(this.ctx, this.gameTime);

        for (const effect of this.groundEffects) effect.draw(this.ctx);
        for (const bullet of this.bullets) bullet.draw(this.ctx);
        for (const enemy of this.enemies) enemy.draw(this.ctx);
        if (this.battleBrother) this.battleBrother.draw(this.ctx);
        for (const proj of this.enemyProjectiles) proj.draw(this.ctx);
        for (const drop of this.ammoDrops) drop.draw(this.ctx);
        for (const pack of this.healthPacks) pack.draw(this.ctx);
        for (const crate of this.powerUpCrates) crate.draw(this.ctx);
        this.player.draw(this.ctx);
        this.particles.draw(this.ctx);
        for (const text of this.floatingTexts) text.draw(this.ctx);

        // 技能圆形范围指示
        if (this.player.skillActive && this.player.skillDuration > 0) {
            const progress = this.player.skillDuration / 20;
            this.ctx.strokeStyle = `rgba(255, 200, 50, ${progress})`;
            this.ctx.lineWidth = 3;
            this.ctx.beginPath();
            this.ctx.arc(this.player.x, this.player.y, this.player.skillRange, 0, Math.PI * 2);
            this.ctx.stroke();
        }

        // 近战扇形范围指示
        if (this.player.meleeActive && this.player.meleeDuration > 0) {
            const meleeBox = this.player.getMeleeHitbox();
            if (meleeBox) {
                this.ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
                this.ctx.beginPath();
                this.ctx.moveTo(meleeBox.x, meleeBox.y);
                this.ctx.arc(meleeBox.x, meleeBox.y, meleeBox.radius, meleeBox.startAngle, meleeBox.endAngle);
                this.ctx.closePath();
                this.ctx.fill();
            }
        }

        // 鼠标准星
        const cx = this.input.mouseX;
        const cy = this.input.mouseY;
        this.ctx.strokeStyle = '#cc0000';
        this.ctx.lineWidth = 1.5;
        this.ctx.shadowColor = '#ff0000';
        this.ctx.shadowBlur = 4;
        // 外圆环
        this.ctx.beginPath();
        this.ctx.arc(cx, cy, 10, 0, Math.PI * 2);
        this.ctx.stroke();
        // 十字线（中间留空）
        const gap = 4;
        const len = 10;
        this.ctx.beginPath();
        this.ctx.moveTo(cx - len, cy); this.ctx.lineTo(cx - gap, cy);
        this.ctx.moveTo(cx + gap, cy); this.ctx.lineTo(cx + len, cy);
        this.ctx.moveTo(cx, cy - len); this.ctx.lineTo(cx, cy - gap);
        this.ctx.moveTo(cx, cy + gap); this.ctx.lineTo(cx, cy + len);
        this.ctx.stroke();
        // 中心点
        this.ctx.fillStyle = '#ff3333';
        this.ctx.beginPath();
        this.ctx.arc(cx, cy, 1.5, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.shadowBlur = 0;
    }
}

// ============================================================
// 启动游戏
// ============================================================
const game = new Game();